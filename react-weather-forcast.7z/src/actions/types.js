export const GET_BY_GEO = 'GET_BY_GEO';
export const GET_BY_CITY = 'GET_BY_CITY';
export const GET_LOCATION = 'GET_LOCATION';